# Python Object Oriented Programming by Joe Marini course example
# Basic class definitions


# TODO: create a basic class


# TODO: create instances of the class


# TODO: print the class and property
